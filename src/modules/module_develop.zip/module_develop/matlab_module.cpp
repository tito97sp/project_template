//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: matlab_module.cpp
//
// Code generated for Simulink model 'matlab_module'.
//
// Model version                  : 1.12
// Simulink Coder version         : 9.5 (R2021a) 14-Nov-2020
// C/C++ source code generated on : Wed Apr 14 13:11:58 2021
//
// Target selection: nuttx_ec.tlc
// Embedded hardware selection: Atmel->AVR
// Code generation objectives: Unspecified
// Validation result: Not run
//
#include "matlab_module.h"
#include "matlab_module_private.h"

// External inputs (root inport signals with default storage)
ExtU_matlab_module_T matlab_module_U;

// External outputs (root outports fed by signals with default storage)
ExtY_matlab_module_T matlab_module_Y;

// Real-time model
RT_MODEL_matlab_module_T matlab_module_M_ = RT_MODEL_matlab_module_T();
RT_MODEL_matlab_module_T *const matlab_module_M = &matlab_module_M_;

// Model step function
void matlab_module_step(void)
{
  // Outport: '<Root>/Out1' incorporates:
  //   Inport: '<Root>/In1'
  //   Inport: '<Root>/In2'
  //   Sum: '<Root>/Sum'

  matlab_module_Y.Out1 = matlab_module_U.In1 + matlab_module_U.In2;
}

// Model initialize function
void matlab_module_initialize(void)
{
  // (no initialization code required)
}

// Model terminate function
void matlab_module_terminate(void)
{
  // (no terminate code required)
}

//
// File trailer for generated code.
//
// [EOF]
//
