#ifndef _MW_UORB_BUSSTRUCT_CONVERSION_H_
#define _MW_UORB_BUSSTRUCT_CONVERSION_H_

#include <uORB/topics/log_message.h>

typedef struct log_message_s  nuttx_Bus_log_message ;

#endif
