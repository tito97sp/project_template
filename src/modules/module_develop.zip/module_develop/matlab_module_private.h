//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: matlab_module_private.h
//
// Code generated for Simulink model 'matlab_module'.
//
// Model version                  : 1.12
// Simulink Coder version         : 9.5 (R2021a) 14-Nov-2020
// C/C++ source code generated on : Wed Apr 14 13:11:58 2021
//
// Target selection: nuttx_ec.tlc
// Embedded hardware selection: Atmel->AVR
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef RTW_HEADER_matlab_module_private_h_
#define RTW_HEADER_matlab_module_private_h_
#include "rtwtypes.h"
#endif                                 // RTW_HEADER_matlab_module_private_h_

//
// File trailer for generated code.
//
// [EOF]
//
